# NetBird AI Insight Tracker

A Next.js application for tracking NetBird's brand visibility in AI-powered search results.

## Features

- 🚀 Multi-step onboarding wizard
- 💼 Business information collection
- 🎯 AI-powered topic suggestions
- 📝 Smart prompt generation
- 🏆 Competitor tracking
- 🎨 Modern UI with Flowbite components
- 📱 Fully responsive design
- 🔧 TypeScript support
- 🚄 Server-side API routes

## Getting Started

### Prerequisites

- Node.js 18.17 or later
- npm or yarn package manager

### Installation

1. Clone or extract this project
2. Install dependencies:
   ```bash
   npm install
   ```

3. Run the development server:
   ```bash
   npm run dev
   ```

4. Open [http://localhost:3000/onboarding](http://localhost:3000/onboarding) in your browser

## Project Structure

```
app/
├── api/              # API routes
├── components/       # React components
├── lib/             # Utilities and types
└── onboarding/      # Onboarding pages
```

## Onboarding Flow

1. **Business Information**: Collect company name and website
2. **Topic Selection**: Choose or add custom topics to track
3. **Prompt Generation**: Select AI search prompts
4. **Competitor Selection**: Choose competitors to monitor

## Technologies Used

- **Next.js 14** - React framework
- **TypeScript** - Type safety
- **Flowbite React** - UI components
- **Tailwind CSS** - Styling
- **React Hook Form** - Form handling

## API Endpoints

- `POST /api/onboarding/business` - Save business information
- `POST /api/onboarding/topics` - Generate topic suggestions
- `POST /api/onboarding/prompts` - Create AI prompts
- `POST /api/onboarding/competitors` - Identify competitors
- `POST /api/onboarding/complete` - Complete onboarding

## Development

### Build for Production

```bash
npm run build
npm start
```

### Linting

```bash
npm run lint
```

## Next Steps

- Add database integration (PostgreSQL/MongoDB)
- Implement authentication
- Build dashboard views
- Add real-time tracking
- Integrate AI search APIs

## License

MIT

## Support

For issues or questions, please create an issue in the repository.
