import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { business, prompts } = body;

    // Generate suggested competitors
    const competitors = [
      { id: '1', name: 'Competitor A', website: 'https://competitor-a.com', selected: true },
      { id: '2', name: 'Competitor B', website: 'https://competitor-b.com', selected: true },
      { id: '3', name: 'Competitor C', website: 'https://competitor-c.com', selected: false },
      { id: '4', name: 'Industry Leader', website: 'https://leader.com', selected: true },
      { id: '5', name: 'Emerging Brand', website: 'https://emerging.com', selected: false },
    ];

    return NextResponse.json({
      success: true,
      competitors
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}