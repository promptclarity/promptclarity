import { NextRequest, NextResponse } from 'next/server';
import { dbHelpers, runTransaction } from '@/app/lib/db/database';
import type { BusinessRecord, OnboardingSession } from '@/app/lib/types';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { businessName, website } = body;

    // Validate input
    if (!businessName || !website) {
      return NextResponse.json(
          { error: 'Business name and website are required' },
          { status: 400 }
      );
    }

    // Validate URL format
    try {
      new URL(website);
    } catch {
      return NextResponse.json(
          { error: 'Invalid website URL format' },
          { status: 400 }
      );
    }

    // todo: we don't need to query by business name here because the business name is not unique
    // todo: instead, we should make sure we can save multiple businesses with the same name or website
    // todo: but we should ensure that when a user goes back to this step, the update can be applied correctly
    // todo: so, we need to keep the generated ID for the business, return it to the client and then if client provides an ID, we use it to update
    // Save to database with transaction
    const result = runTransaction(() => {
      // Check if business already exists
      const existingBusiness = dbHelpers.getBusinessByName.get(businessName) as BusinessRecord | undefined;

      let business: BusinessRecord;
      let session: OnboardingSession;

      if (existingBusiness) {
        // Update existing business
        dbHelpers.updateBusiness.run({
          id: existingBusiness.id,
          businessName,
          website
        });
        business = dbHelpers.getBusiness.get(existingBusiness.id) as BusinessRecord;

        // Get or create session
        let existingSession = dbHelpers.getSession.get(existingBusiness.id) as OnboardingSession | undefined;
        if (!existingSession) {
          dbHelpers.createSession.run({
            businessId: existingBusiness.id,
            stepCompleted: 1
          });
          existingSession = dbHelpers.getSession.get(existingBusiness.id) as OnboardingSession;
        } else {
          // Update session step
          dbHelpers.updateSession.run({
            businessId: existingBusiness.id,
            stepCompleted: Math.max(existingSession.step_completed, 1)
          });
        }
        session = existingSession;
      } else {
        // Create new business
        const insertResult = dbHelpers.createBusiness.run({
          businessName,
          website
        });

        const businessId = insertResult.lastInsertRowid as number;
        business = dbHelpers.getBusiness.get(businessId) as BusinessRecord;

        // Create new session
        dbHelpers.createSession.run({
          businessId,
          stepCompleted: 1
        });
        session = dbHelpers.getSession.get(businessId) as OnboardingSession;
      }

      return { business, session };
    });

    return NextResponse.json({
      success: true,
      data: {
        businessId: result.business.id,
        businessName: result.business.business_name,
        website: result.business.website,
        sessionId: result.session.id,
        stepCompleted: result.session.step_completed
      }
    });
  } catch (error) {
    console.error('Error saving business info:', error);
    return NextResponse.json(
        { error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown error' },
        { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const businessId = searchParams.get('businessId');

    if (!businessId) {
      return NextResponse.json(
          { error: 'Business ID is required' },
          { status: 400 }
      );
    }

    const business = dbHelpers.getBusiness.get(parseInt(businessId)) as BusinessRecord | undefined;

    if (!business) {
      return NextResponse.json(
          { error: 'Business not found' },
          { status: 404 }
      );
    }

    const session = dbHelpers.getSession.get(parseInt(businessId)) as OnboardingSession | undefined;

    return NextResponse.json({
      success: true,
      data: {
        business: {
          id: business.id,
          businessName: business.business_name,
          website: business.website,
          createdAt: business.created_at,
          updatedAt: business.updated_at
        },
        session: session ? {
          id: session.id,
          stepCompleted: session.step_completed,
          completed: session.completed,
          completedAt: session.completed_at
        } : null
      }
    });
  } catch (error) {
    console.error('Error fetching business info:', error);
    return NextResponse.json(
        { error: 'Internal server error' },
        { status: 500 }
    );
  }
}