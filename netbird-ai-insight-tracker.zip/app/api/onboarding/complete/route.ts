import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { business, topics, prompts, competitors } = body;

    // Validate all required data
    if (!business.businessName || !business.website) {
      return NextResponse.json(
        { error: 'Business information is incomplete' },
        { status: 400 }
      );
    }

    const selectedTopics = topics.filter((t: any) => t.selected);
    const selectedPrompts = prompts.filter((p: any) => p.selected);
    const selectedCompetitors = competitors.filter((c: any) => c.selected);

    if (selectedTopics.length === 0) {
      return NextResponse.json(
        { error: 'At least one topic must be selected' },
        { status: 400 }
      );
    }

    if (selectedPrompts.length === 0) {
      return NextResponse.json(
        { error: 'At least one prompt must be selected' },
        { status: 400 }
      );
    }

    // Save to database
    const onboardingData = {
      business,
      topics: selectedTopics,
      prompts: selectedPrompts,
      competitors: selectedCompetitors,
      completedAt: new Date().toISOString(),
    };

    console.log('Onboarding completed:', onboardingData);

    return NextResponse.json({
      success: true,
      message: 'Onboarding completed successfully',
      redirectUrl: '/dashboard'
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}