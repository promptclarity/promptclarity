import { NextRequest, NextResponse } from 'next/server';
import { dbHelpers, runTransaction } from '@/app/lib/db/database';
import { generatePromptsForTopics } from '@/app/lib/services/ai.service';
import type { BusinessRecord, TopicRecord, PromptRecord } from '@/app/lib/types';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { businessId, prompts, generateSuggestions } = body;

    if (!businessId) {
      return NextResponse.json(
          { error: 'Business ID is required' },
          { status: 400 }
      );
    }

    // Get business details
    const business = dbHelpers.getBusiness.get(businessId) as BusinessRecord;
    if (!business) {
      return NextResponse.json(
          { error: 'Business not found' },
          { status: 404 }
      );
    }

    // Generate AI-powered suggestions
    if (generateSuggestions) {
      try {
        // Get topics for the business
        const topics = dbHelpers.getTopicsByBusiness.all(businessId) as TopicRecord[];
        
        if (topics.length === 0) {
          return NextResponse.json(
              { error: 'No topics found for this business' },
              { status: 400 }
          );
        }

        // Call AI service to generate prompts
        const generatedPrompts = await generatePromptsForTopics(
            business.business_name,
            business.website,
            topics.map(t => t.name)
        );

        // Map prompts to include topic IDs
        const promptsWithIds = generatedPrompts.map((prompt, index) => {
          const topic = topics.find(t => t.name === prompt.topicName);
          return {
            id: `generated-${index}`,
            text: prompt.text,
            topicId: topic?.id || topics[0].id,
            topicName: prompt.topicName,
          };
        });

        return NextResponse.json({
          success: true,
          prompts: promptsWithIds,
          generated: true
        });
      } catch (error) {
        console.error('Error generating prompts:', error);
        return NextResponse.json(
            { error: 'Failed to generate prompts', details: error instanceof Error ? error.message : 'Unknown error' },
            { status: 500 }
        );
      }
    }

    // Save user-modified prompts
    if (prompts && Array.isArray(prompts)) {
      const savedPrompts = runTransaction(() => {
        dbHelpers.deletePromptsByBusiness.run(businessId);

        const insertedPrompts: any[] = [];
        for (const prompt of prompts) {
          const result = dbHelpers.createPrompt.run({
            businessId,
            topicId: prompt.topicId || null,
            text: prompt.text,
            isCustom: prompt.isCustom ? 1 : 0
          });

          insertedPrompts.push({
            id: result.lastInsertRowid,
            ...prompt
          });
        }

        dbHelpers.updateSession.run({
          businessId,
          stepCompleted: 3
        });

        return insertedPrompts;
      });

      return NextResponse.json({
        success: true,
        prompts: savedPrompts
      });
    }

    return NextResponse.json(
        { error: 'Invalid request' },
        { status: 400 }
    );
  } catch (error) {
    console.error('Error handling prompts:', error);
    return NextResponse.json(
        { error: 'Internal server error' },
        { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const businessId = searchParams.get('businessId');

    if (!businessId) {
      return NextResponse.json(
          { error: 'Business ID is required' },
          { status: 400 }
      );
    }

    const prompts = dbHelpers.getPromptsByBusiness.all(parseInt(businessId)) as PromptRecord[];

    return NextResponse.json({
      success: true,
      prompts: prompts.map(prompt => ({
        id: prompt.id.toString(),
        text: prompt.text,
        topicId: prompt.topic_id,
        topicName: prompt.topic_name,
        isCustom: prompt.is_custom
      }))
    });
  } catch (error) {
    console.error('Error fetching prompts:', error);
    return NextResponse.json(
        { error: 'Internal server error' },
        { status: 500 }
    );
  }
}