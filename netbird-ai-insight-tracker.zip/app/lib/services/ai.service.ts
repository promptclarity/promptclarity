import { generateObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { anthropic } from '@ai-sdk/anthropic';
import { z } from 'zod';

// Schema for topic validation
const TopicSchema = z.object({
    name: z.string(),
});

const TopicsResponseSchema = z.object({
    topics: z.array(TopicSchema).min(5).max(10),
});

// Schema for prompt validation
const PromptSchema = z.object({
    text: z.string(),
    topicName: z.string(),
});

const PromptsResponseSchema = z.object({
    prompts: z.array(PromptSchema),
});

export type GeneratedTopic = z.infer<typeof TopicSchema>;
export type TopicsResponse = z.infer<typeof TopicsResponseSchema>;
export type GeneratedPrompt = z.infer<typeof PromptSchema>;
export type PromptsResponse = z.infer<typeof PromptsResponseSchema>;

// Get AI model based on provider
function getAIModel() {
    const provider = process.env.AI_PROVIDER || 'anthropic';

    switch (provider) {
        case 'openai':
            return openai('gpt-4o');
        case 'anthropic':
            return anthropic('claude-3-opus-20240229');
        default:
            // Default to Anthropic Claude
            return anthropic('claude-3-opus-20240229');
    }
}

export async function generateTopicsForBusiness(
    businessName: string,
    website: string
): Promise<GeneratedTopic[]> {
    try {
        const model = getAIModel();

        const prompt = `
      You are an AI marketing analyst helping businesses track their presence in AI-powered search results.
      
      Business Name: ${businessName}
      Website: ${website}
      
      Based on the business name and website URL, generate 5 relevant topics that would be useful for tracking 
      this business's visibility in AI search platforms. Consider the likely industry, business type, product or service.
      Generate exactly 5 relevant topics for tracking this business in AI search platforms that is relevant to the business's
      industry. The topics should be high level and not be too specific. The topics should not include brand name.
      
      Here are a few examples of topics that could be generated for a brand American Express https://www.americanexpress.com/:
      - Banking
      - Credit Cards
      - Personal Finance
      - Brokerage Services
      - Wealth Management
      
      Make sure the length of the topics is not more than 5 words.
    `;

        const { object } = await generateObject({
            model,
            schema: TopicsResponseSchema,
            prompt,
            temperature: 0.7,
            maxOutputTokens: 15000,
        });

        return object.topics;
    } catch (error) {
        console.error('Error generating topics:', error);

        // Fallback to default topics if AI generation fails
        // todo use another model?
        return getFallbackTopics(businessName);
    }
}

// Fallback topics in case AI generation fails
function getFallbackTopics(businessName: string): GeneratedTopic[] {
    return [
        {
            name: `${businessName} reviews`,
        },
        {
            name: `${businessName} vs competitors`,
        },
        {
            name: `${businessName} pricing`,
        },
        {
            name: `${businessName} features`,
        },
        {
            name: `${businessName} alternatives`,
        },
        {
            name: `${businessName} integration`,
        },
        {
            name: `Industry trends`,
        },
        {
            name: `Customer support`,
        },
        {
            name: `Use cases`,
        },
        {
            name: `Best practices`,
        },
    ];
}

export async function generatePromptsForTopics(
    businessName: string,
    website: string,
    topics: string[]
): Promise<GeneratedPrompt[]> {
    try {
        const model = getAIModel();

        const prompt = `
      You are an AI marketing analyst helping businesses track their presence in AI-powered search results.
      
      Business Name: ${businessName}
      Website: ${website}
      Topics: ${topics.join(', ')}
      
      Generate search prompts that users might type into AI assistants (like ChatGPT, Claude, Gemini) 
      when looking for information related to these topics. The prompts should help track when the business
      might be mentioned or recommended.
      
      For each topic, generate 2-3 different search prompts that:
      1. One prompt asking for recommendations/comparisons in that topic area
      2. One prompt asking about best solutions/tools for that topic
      3. One prompt that might naturally lead to mentioning the business
      
      The prompts should be natural questions users would actually ask AI assistants.
      Each prompt should be associated with its relevant topic name.
      
      Example for topic "Credit Cards" and business "American Express":
      - "What are the best travel credit cards in 2024?"
      - "Compare premium credit cards with airport lounge access"
      - "Which credit card has the best rewards program for dining?"
      
      Generate a total of ${topics.length * 2} to ${topics.length * 3} prompts across all topics.
    `;

        const { object } = await generateObject({
            model,
            schema: PromptsResponseSchema,
            prompt,
            temperature: 0.7,
            maxOutputTokens: 15000,
        });

        return object.prompts;
    } catch (error) {
        console.error('Error generating prompts:', error);
        return getFallbackPrompts(businessName, topics);
    }
}

// Fallback prompts in case AI generation fails
function getFallbackPrompts(businessName: string, topics: string[]): GeneratedPrompt[] {
    const prompts: GeneratedPrompt[] = [];
    
    for (const topic of topics) {
        prompts.push({
            text: `What are the best ${topic.toLowerCase()} solutions in 2024?`,
            topicName: topic,
        });
        
        prompts.push({
            text: `Compare top ${topic.toLowerCase()} providers`,
            topicName: topic,
        });
        
        if (prompts.length < topics.length * 3) {
            prompts.push({
                text: `${businessName} vs alternatives for ${topic.toLowerCase()}`,
                topicName: topic,
            });
        }
    }
    
    return prompts;
}