export interface BusinessInfo {
  businessName: string;
  website: string;
}

export interface Topic {
  id: string;
  name: string;
  isCustom?: boolean;
}

export interface Prompt {
  id: string;
  text: string;
  topicId?: number | string;
  topicName?: string;
  isCustom?: boolean;
}

export interface Competitor {
  id: string;
  name: string;
  website?: string;
  selected: boolean;
}

export interface OnboardingData {
  business: BusinessInfo;
  topics: Topic[];
  prompts: Prompt[];
  competitors: Competitor[];
}

export enum OnboardingStep {
  BUSINESS = 1,
  TOPICS = 2,
  PROMPTS = 3,
  COMPETITORS = 4,
}

// Database record types
export interface BusinessRecord {
  id: number;
  business_name: string;
  website: string;
  created_at: string;
  updated_at: string;
}

export interface OnboardingSession {
  id: number;
  business_id: number;
  step_completed: number;
  completed: boolean;
  completed_at?: string;
  created_at: string;
  updated_at: string;
}

export interface TopicRecord {
  id: number;
  business_id: number;
  name: string;
  is_custom: boolean;
  created_at: string;
}

export interface PromptRecord {
  id: number;
  business_id: number;
  topic_id?: number;
  text: string;
  is_custom: boolean;
  created_at: string;
  topic_name?: string;
}

export interface CompetitorRecord {
  id: number;
  business_id: number;
  name: string;
  website?: string;
  visibility_score?: number;
  selected: boolean;
  is_custom: boolean;
  created_at: string;
}