import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

const dataDir = path.join(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

const db = new Database(path.join(dataDir, 'store.db'));
db.pragma('foreign_keys = ON');

// Initialize schema
db.exec(`
  CREATE TABLE IF NOT EXISTS businesses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_name TEXT NOT NULL,
    website TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS onboarding_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL,
    step_completed INTEGER DEFAULT 1,
    completed BOOLEAN DEFAULT 0,
    completed_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    is_custom BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS prompts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL,
    topic_id INTEGER,
    text TEXT NOT NULL,
    is_custom BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    FOREIGN KEY (topic_id) REFERENCES topics(id) ON DELETE SET NULL
  );
`);

// Helper functions
export const dbHelpers = {
    createBusiness: db.prepare(`
    INSERT INTO businesses (business_name, website)
    VALUES (@businessName, @website)
  `),

    updateBusiness: db.prepare(`
    UPDATE businesses 
    SET business_name = @businessName, 
        website = @website,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = @id
  `),

    getBusiness: db.prepare(`
    SELECT * FROM businesses WHERE id = ?
  `),

    getBusinessByName: db.prepare(`
    SELECT * FROM businesses WHERE business_name = ?
  `),

    createSession: db.prepare(`
    INSERT INTO onboarding_sessions (business_id, step_completed)
    VALUES (@businessId, @stepCompleted)
  `),

    updateSession: db.prepare(`
    UPDATE onboarding_sessions
    SET step_completed = @stepCompleted,
        updated_at = CURRENT_TIMESTAMP
    WHERE business_id = @businessId
  `),

    getSession: db.prepare(`
    SELECT * FROM onboarding_sessions WHERE business_id = ?
  `),

    createTopic: db.prepare(`
    INSERT INTO topics (business_id, name, is_custom)
    VALUES (@businessId, @name, @isCustom)
  `),

    getTopicsByBusiness: db.prepare(`
    SELECT * FROM topics WHERE business_id = ? ORDER BY created_at
  `),

    deleteTopicsByBusiness: db.prepare(`
    DELETE FROM topics WHERE business_id = ?
  `),

    createPrompt: db.prepare(`
    INSERT INTO prompts (business_id, topic_id, text, is_custom)
    VALUES (@businessId, @topicId, @text, @isCustom)
  `),

    getPromptsByBusiness: db.prepare(`
    SELECT p.*, t.name as topic_name 
    FROM prompts p
    LEFT JOIN topics t ON p.topic_id = t.id
    WHERE p.business_id = ? 
    ORDER BY p.created_at
  `),

    deletePromptsByBusiness: db.prepare(`
    DELETE FROM prompts WHERE business_id = ?
  `),
};

export function runTransaction<T>(fn: () => T): T {
    return db.transaction(fn)();
}

export default db;