'use client';

import { useState, useEffect } from 'react';
import { Button, Label, TextInput, Spinner, Alert } from 'flowbite-react';
import { BusinessInfo } from '@/app/lib/types';

interface Topic {
  id: string;
  name: string;
  isCustom?: boolean;
}

interface TopicsStepProps {
  businessData: BusinessInfo;
  topics: Topic[];
  onUpdate: (topics: Topic[]) => void;
  onNext: () => void;
  onBack: () => void;
}

export default function TopicsStep({
                                     businessData,
                                     topics,
                                     onUpdate,
                                     onNext,
                                     onBack,
                                   }: TopicsStepProps) {
  const [selectedTopics, setSelectedTopics] = useState<Topic[]>(topics);
  const [customTopic, setCustomTopic] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasGenerated, setHasGenerated] = useState(false);

  useEffect(() => {
    // Automatically generate topics when component mounts if no topics exist
    if (topics.length === 0 && !hasGenerated) {
      generateTopics();
    }
  }, []);

  const generateTopics = async () => {
    setIsGenerating(true);
    setError(null);

    try {
      const businessId = localStorage.getItem('onboardingBusinessId');
      if (!businessId) {
        throw new Error('Business ID not found');
      }

      const response = await fetch('/api/onboarding/topics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessId: parseInt(businessId),
          generateSuggestions: true,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to generate topics');
      }

      const data = await response.json();
      setSelectedTopics(data.topics);
      setHasGenerated(true);
    } catch (error) {
      console.error('Error generating topics:', error);
      setError(error instanceof Error ? error.message : 'Failed to generate topics. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };


  const handleAddCustomTopic = () => {
    if (customTopic.trim()) {
      const newTopic: Topic = {
        id: `custom-${Date.now()}`,
        name: customTopic.trim(),
        isCustom: true,
      };
      setSelectedTopics([...selectedTopics, newTopic]);
      setCustomTopic('');
    }
  };

  const handleRemoveTopic = (topicId: string) => {
    setSelectedTopics(prev => prev.filter(topic => topic.id !== topicId));
  };

  const handleSubmit = async () => {
    if (selectedTopics.length === 0) {
      setError('Please add at least one topic');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const businessId = localStorage.getItem('onboardingBusinessId');
      const response = await fetch('/api/onboarding/topics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessId: parseInt(businessId!),
          topics: selectedTopics,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to save topics');
      }

      onUpdate(selectedTopics);
      onNext();
    } catch (error) {
      console.error('Error saving topics:', error);
      setError('Failed to save topics. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };


  if (isGenerating) {
    return (
        <div className="flex flex-col justify-center items-center h-64 space-y-4">
          <Spinner size="xl" />
          <div className="text-center">
            <p className="text-lg font-medium">Analyzing your business...</p>
            <p className="text-sm text-gray-600 mt-2">
              AI is generating relevant topics for {businessData.businessName}
            </p>
          </div>
        </div>
    );
  }

  return (
      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold mb-2">Topic Selection</h2>
          <p className="text-gray-600 mb-6">
            AI has generated topics based on your business. Select the ones you'd like to track.
          </p>
        </div>

        {error && (
            <Alert color="failure">
              <span>{error}</span>
            </Alert>
        )}

        <div className="space-y-3">
          <div className="flex justify-between items-center mb-2">
            <Label value="AI-Generated Topics" />
            <Button size="xs" color="gray" onClick={generateTopics} disabled={isGenerating}>
              Regenerate Topics
            </Button>
          </div>

          <div className="border rounded-lg p-4 space-y-3 max-h-96 overflow-y-auto">
            {selectedTopics.map((topic) => (
                <div key={topic.id} className="border-b pb-3 last:border-b-0">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start flex-1">
                      <div className="flex-1">
                        <Label htmlFor={topic.id} className="font-medium">
                          {topic.name}
                        </Label>
                      </div>
                    </div>
                    <Button
                        size="xs"
                        color="gray"
                        onClick={() => handleRemoveTopic(topic.id)}
                    >
                      Remove
                    </Button>
                  </div>
                </div>
            ))}
          </div>
        </div>

        <div className="flex gap-2">
          <TextInput
              placeholder="Add custom topic..."
              value={customTopic}
              onChange={(e) => setCustomTopic(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddCustomTopic()}
              className="flex-1"
          />
          <Button onClick={handleAddCustomTopic} color="gray">
            Add Topic
          </Button>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <p className="text-sm text-blue-800">
            <strong>{selectedTopics.length}</strong> topics will be tracked
          </p>
        </div>

        <div className="flex justify-between">
          <Button color="gray" onClick={onBack}>
            Back
          </Button>
          <Button onClick={handleSubmit} disabled={isLoading || selectedTopics.length === 0}>
            {isLoading ? 'Saving...' : 'Next: Generate Prompts'}
          </Button>
        </div>
      </div>
  );
}