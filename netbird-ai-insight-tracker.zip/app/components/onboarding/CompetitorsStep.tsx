'use client';

import { useState, useEffect } from 'react';
import { Button, Checkbox, Label, TextInput, Spinner } from 'flowbite-react';
import { BusinessInfo, Prompt, Competitor } from '@/app/lib/types';

interface CompetitorsStepProps {
  businessData: BusinessInfo;
  prompts: Prompt[];
  competitors: Competitor[];
  onUpdate: (competitors: Competitor[]) => void;
  onComplete: () => void;
  onBack: () => void;
  isLoading: boolean;
}

export default function CompetitorsStep({
  businessData,
  prompts,
  competitors,
  onUpdate,
  onComplete,
  onBack,
  isLoading,
}: CompetitorsStepProps) {
  const [selectedCompetitors, setSelectedCompetitors] = useState<Competitor[]>(competitors);
  const [customCompetitor, setCustomCompetitor] = useState('');
  const [isFetching, setIsFetching] = useState(true);

  useEffect(() => {
    if (competitors.length === 0) {
      fetchSuggestedCompetitors();
    } else {
      setIsFetching(false);
    }
  }, []);

  const fetchSuggestedCompetitors = async () => {
    setIsFetching(true);
    try {
      const response = await fetch('/api/onboarding/competitors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          business: businessData,
          prompts: prompts.filter(p => p.selected),
        }),
      });
      
      if (response.ok) {
        const data = await response.json();
        setSelectedCompetitors(data.competitors);
      }
    } catch (error) {
      console.error('Error fetching competitors:', error);
    } finally {
      setIsFetching(false);
    }
  };

  const handleCompetitorToggle = (competitorId: string) => {
    setSelectedCompetitors(prev =>
      prev.map(comp =>
        comp.id === competitorId ? { ...comp, selected: !comp.selected } : comp
      )
    );
  };

  const handleAddCustomCompetitor = () => {
    if (customCompetitor.trim()) {
      const newCompetitor: Competitor = {
        id: `custom-${Date.now()}`,
        name: customCompetitor.trim(),
        selected: true,
      };
      setSelectedCompetitors([...selectedCompetitors, newCompetitor]);
      setCustomCompetitor('');
    }
  };

  const handleRemoveCompetitor = (competitorId: string) => {
    setSelectedCompetitors(prev => prev.filter(comp => comp.id !== competitorId));
  };

  const handleSubmit = () => {
    onUpdate(selectedCompetitors);
    onComplete();
  };

  if (isFetching) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spinner size="xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-2">Competition Tracking</h2>
        <p className="text-gray-600 mb-6">
          We've identified 5 competitors based on your prompts. Select the ones you'd like to track and compare.
        </p>
      </div>

      <div className="space-y-3">
        <Label value="Suggested Competitors" />
        <div className="border rounded-lg p-4 space-y-3 max-h-64 overflow-y-auto">
          {selectedCompetitors.map((competitor) => (
            <div key={competitor.id} className="flex items-center justify-between">
              <div className="flex items-center flex-1">
                <Checkbox
                  id={competitor.id}
                  checked={competitor.selected}
                  onChange={() => handleCompetitorToggle(competitor.id)}
                />
                <div className="ml-3 flex-1">
                  <Label htmlFor={competitor.id} className="font-normal">
                    {competitor.name}
                  </Label>
                  {competitor.website && (
                    <p className="text-sm text-gray-500">{competitor.website}</p>
                  )}
                </div>
              </div>
              {competitor.id.startsWith('custom-') && (
                <Button
                  size="xs"
                  color="gray"
                  onClick={() => handleRemoveCompetitor(competitor.id)}
                >
                  Remove
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-2">
        <TextInput
          placeholder="Add competitor name..."
          value={customCompetitor}
          onChange={(e) => setCustomCompetitor(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleAddCustomCompetitor()}
          className="flex-1"
        />
        <Button onClick={handleAddCustomCompetitor} color="gray">
          Add Competitor
        </Button>
      </div>

      <div className="flex justify-between">
        <Button color="gray" onClick={onBack}>
          Back
        </Button>
        <Button onClick={handleSubmit} disabled={isLoading}>
          {isLoading ? 'Completing Setup...' : 'Go to Dashboard'}
        </Button>
      </div>
    </div>
  );
}