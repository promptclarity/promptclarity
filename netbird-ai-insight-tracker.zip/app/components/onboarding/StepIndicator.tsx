'use client';

import { OnboardingStep } from '@/app/lib/types';

interface StepIndicatorProps {
  currentStep: OnboardingStep;
}

export default function StepIndicator({ currentStep }: StepIndicatorProps) {
  const steps = [
    { id: OnboardingStep.BUSINESS, label: 'Business Info' },
    { id: OnboardingStep.TOPICS, label: 'Topics' },
    { id: OnboardingStep.PROMPTS, label: 'Prompts' },
    { id: OnboardingStep.COMPETITORS, label: 'Competitors' },
  ];

  return (
    <ol className="flex items-center w-full">
      {steps.map((step, index) => (
        <li
          key={step.id}
          className={`flex items-center ${
            index < steps.length - 1 ? 'w-full' : ''
          }`}
        >
          <span
            className={`flex items-center justify-center w-10 h-10 rounded-full lg:h-12 lg:w-12 shrink-0 ${
              currentStep >= step.id
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-500'
            }`}
          >
            {step.id}
          </span>
          <span className="ml-2 text-sm font-medium">
            {step.label}
          </span>
          {index < steps.length - 1 && (
            <div
              className={`w-full h-0.5 mx-4 ${
                currentStep > step.id ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            />
          )}
        </li>
      ))}
    </ol>
  );
}