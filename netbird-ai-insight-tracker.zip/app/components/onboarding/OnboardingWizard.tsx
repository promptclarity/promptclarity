'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button, Card } from 'flowbite-react';
import BusinessStep from './BusinessStep';
import TopicsStep from './TopicsStep';
import PromptsStep from './PromptsStep';
import CompetitorsStep from './CompetitorsStep';
import StepIndicator from './StepIndicator';
import { OnboardingData, OnboardingStep } from '@/app/lib/types';

export default function OnboardingWizard() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState<OnboardingStep>(OnboardingStep.BUSINESS);
  const [isLoading, setIsLoading] = useState(false);
  
  const [onboardingData, setOnboardingData] = useState<OnboardingData>({
    business: { businessName: '', website: '' },
    topics: [],
    prompts: [],
    competitors: [],
  });

  const handleNextStep = () => {
    if (currentStep < OnboardingStep.COMPETITORS) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > OnboardingStep.BUSINESS) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/onboarding/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(onboardingData),
      });
      
      if (response.ok) {
        router.push('/dashboard');
      }
    } catch (error) {
      console.error('Error completing onboarding:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateData = (data: Partial<OnboardingData>) => {
    setOnboardingData(prev => ({ ...prev, ...data }));
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card className="p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            AI Search Results Insight Tracker
          </h1>
          <p className="text-gray-600">
            Set up your brand monitoring to track AI search visibility
          </p>
        </div>

        <StepIndicator currentStep={currentStep} />

        <div className="mt-8">
          {currentStep === OnboardingStep.BUSINESS && (
            <BusinessStep
              data={onboardingData.business}
              onUpdate={(business) => updateData({ business })}
              onNext={handleNextStep}
            />
          )}

          {currentStep === OnboardingStep.TOPICS && (
            <TopicsStep
              businessData={onboardingData.business}
              topics={onboardingData.topics}
              onUpdate={(topics) => updateData({ topics })}
              onNext={handleNextStep}
              onBack={handlePreviousStep}
            />
          )}

          {currentStep === OnboardingStep.PROMPTS && (
            <PromptsStep
              businessData={onboardingData.business}
              topics={onboardingData.topics}
              prompts={onboardingData.prompts}
              onUpdate={(prompts) => updateData({ prompts })}
              onNext={handleNextStep}
              onBack={handlePreviousStep}
            />
          )}

          {currentStep === OnboardingStep.COMPETITORS && (
            <CompetitorsStep
              businessData={onboardingData.business}
              prompts={onboardingData.prompts}
              competitors={onboardingData.competitors}
              onUpdate={(competitors) => updateData({ competitors })}
              onComplete={handleComplete}
              onBack={handlePreviousStep}
              isLoading={isLoading}
            />
          )}
        </div>
      </Card>
    </div>
  );
}