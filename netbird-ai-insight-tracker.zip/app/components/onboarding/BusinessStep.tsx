'use client';

import { useState } from 'react';
import { Button, Label, TextInput } from 'flowbite-react';
import { BusinessInfo } from '@/app/lib/types';

interface BusinessStepProps {
  data: BusinessInfo;
  onUpdate: (data: BusinessInfo) => void;
  onNext: () => void;
}

export default function BusinessStep({ data, onUpdate, onNext }: BusinessStepProps) {
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo>(data);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!businessInfo.businessName.trim()) {
      newErrors.businessName = 'Business name is required';
    }
    
    if (!businessInfo.website.trim()) {
      newErrors.website = 'Website is required';
    } else if (!/^https?:\/\/.+\..+/.test(businessInfo.website)) {
      newErrors.website = 'Please enter a valid URL';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/onboarding/business', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(businessInfo),
      });
      
      if (response.ok) {
        const result = await response.json();
        
        // Critical: businessId MUST be present in the response
        if (!result.data?.businessId) {
          throw new Error('Server error: Business ID was not returned. Please try again or contact support.');
        }
        
        localStorage.setItem('onboardingBusinessId', result.data.businessId.toString());
        onUpdate(businessInfo);
        onNext();
      } else {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to save business information');
      }
    } catch (error) {
      console.error('Error saving business info:', error);
      setErrors({ 
        submit: error instanceof Error ? error.message : 'An unexpected error occurred. Please try again.' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-2">Business Information</h2>
        <p className="text-gray-600 mb-6">
          We need this information to track, analyze, and generate associated topics for your brand
        </p>
      </div>

      <div>
        <Label htmlFor="businessName" value="Business/Brand Name *" />
        <TextInput
          id="businessName"
          type="text"
          placeholder="Enter your business name"
          value={businessInfo.businessName}
          onChange={(e) => setBusinessInfo({ ...businessInfo, businessName: e.target.value })}
          color={errors.businessName ? 'failure' : undefined}
          helperText={errors.businessName}
          required
        />
      </div>

      <div>
        <Label htmlFor="website" value="Business/Brand Website *" />
        <TextInput
          id="website"
          type="url"
          placeholder="https://example.com"
          value={businessInfo.website}
          onChange={(e) => setBusinessInfo({ ...businessInfo, website: e.target.value })}
          color={errors.website ? 'failure' : undefined}
          helperText={errors.website}
          required
        />
      </div>

      {errors.submit && (
        <div className="rounded-lg bg-red-50 border border-red-200 p-4">
          <p className="text-sm text-red-800">{errors.submit}</p>
        </div>
      )}

      <div className="flex justify-end">
        <Button type="submit" disabled={isLoading}>
          {isLoading ? 'Processing...' : 'Next: Select Topics'}
        </Button>
      </div>
    </form>
  );
}